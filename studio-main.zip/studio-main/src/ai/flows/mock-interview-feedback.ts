'use server';

/**
 * @fileOverview An AI-driven mock interview feedback flow.
 *
 * - mockInterviewFeedback - A function that processes interview responses and provides feedback.
 * - MockInterviewFeedbackInput - The input type for the mockInterviewFeedback function.
 * - MockInterviewFeedbackOutput - The return type for the mockInterviewFeedback function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MockInterviewFeedbackInputSchema = z.object({
  interviewResponse: z.string().describe('The candidate\'s response during the mock interview.'),
  jobDescription: z.string().describe('The description of the job being interviewed for.'),
  userName: z.string().describe('The name of the user'),
});

export type MockInterviewFeedbackInput = z.infer<typeof MockInterviewFeedbackInputSchema>;

const MockInterviewFeedbackOutputSchema = z.object({
  overallFeedback: z.string().describe('Overall feedback on the interview response.'),
  vocalToneFeedback: z.string().describe('Feedback on the vocal tone used in the response.'),
  confidenceLevelFeedback: z.string().describe('Feedback on the confidence level conveyed in the response.'),
  answerQualityFeedback: z.string().describe('Feedback on the quality and relevance of the answer.'),
});

export type MockInterviewFeedbackOutput = z.infer<typeof MockInterviewFeedbackOutputSchema>;

export async function mockInterviewFeedback(input: MockInterviewFeedbackInput): Promise<MockInterviewFeedbackOutput> {
  return mockInterviewFeedbackFlow(input);
}

const prompt = ai.definePrompt({
  name: 'mockInterviewFeedbackPrompt',
  input: {schema: MockInterviewFeedbackInputSchema},
  output: {schema: MockInterviewFeedbackOutputSchema},
  prompt: `You are an AI interview coach providing feedback to {{{userName}}} on their mock interview response based on the following job description:

Job Description: {{{jobDescription}}}

Interview Response: {{{interviewResponse}}}

Provide detailed feedback in the following areas:

- Overall feedback: Provide a summary of the response, highlighting strengths and areas for improvement.
- Vocal tone feedback: Analyze the vocal tone used in the response and provide feedback on clarity, enthusiasm, and engagement.
- Confidence level feedback: Assess the confidence level conveyed in the response and provide feedback on assertiveness and conviction.
- Answer quality feedback: Evaluate the quality and relevance of the answer, including its structure, content, and coherence. Be as specific as possible.
\nEnsure feedback is constructive and actionable so that {{{userName}}} can improve their interviewing skills.
\nOutput the feedback in JSON format.`,
});

const mockInterviewFeedbackFlow = ai.defineFlow(
  {
    name: 'mockInterviewFeedbackFlow',
    inputSchema: MockInterviewFeedbackInputSchema,
    outputSchema: MockInterviewFeedbackOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
