import { config } from 'dotenv';
config();

import '@/ai/flows/resume-ats-analysis.ts';
import '@/ai/flows/mock-interview-feedback.ts';