'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { handleResumeAnalysis } from '@/app/actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, Terminal, UploadCloud, CheckCircle, ListChecks } from 'lucide-react';
import type { AnalyzeResumeAtsOutput } from '@/ai/flows/resume-ats-analysis';
import { useToast } from '@/hooks/use-toast';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';

const formSchema = z.object({
  resume: z
    .custom<FileList>()
    .refine((files) => files?.length > 0, 'A resume file is required.')
    .refine((files) => files?.[0]?.type === 'application/pdf', 'Only PDF files are accepted.')
    .refine((files) => files?.[0]?.size <= 5 * 1024 * 1024, 'File size must be less than 5MB.'),
});

export function ResumeAtsChecker() {
  const [analysis, setAnalysis] = useState<AnalyzeResumeAtsOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      resume: undefined,
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsLoading(true);
    setAnalysis(null);

    const file = values.resume[0];
    const reader = new FileReader();

    reader.onload = async (e) => {
      const dataUri = e.target?.result as string;
      if (!dataUri) {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: 'Could not read the file.',
        });
        setIsLoading(false);
        return;
      }
      
      const result = await handleResumeAnalysis({ resumeDataUri: dataUri });

      if (result.error) {
        toast({
          variant: 'destructive',
          title: 'Analysis Failed',
          description: result.error,
        });
      } else if (result.data) {
        setAnalysis(result.data);
      }
      setIsLoading(false);
    };

    reader.onerror = () => {
        toast({
            variant: 'destructive',
            title: 'Error',
            description: 'Failed to read file.',
        });
        setIsLoading(false);
    };

    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="resume"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Resume File</FormLabel>
                <FormControl>
                  <Input 
                    type="file" 
                    accept="application/pdf"
                    onChange={(e) => field.onChange(e.target.files)} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" disabled={isLoading} className="w-full sm:w-auto">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <UploadCloud className="mr-2 h-4 w-4" />
                Analyze Resume
              </>
            )}
          </Button>
        </form>
      </Form>

      {isLoading && (
        <div className="flex flex-col items-center justify-center space-y-4 rounded-lg border border-dashed p-8">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <p className="text-muted-foreground">Analyzing your resume... This may take a moment.</p>
        </div>
      )}

      {analysis && (
        <div className="space-y-6 animate-in fade-in-50 duration-500">
          <Card>
            <CardHeader className="flex flex-row items-center gap-4">
                <div className="relative h-24 w-24">
                    <svg className="h-full w-full -rotate-90" viewBox="0 0 36 36">
                        <path
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="hsl(var(--secondary))"
                        strokeWidth="3"
                        />
                        <path
                        d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                        fill="none"
                        stroke="hsl(var(--primary))"
                        strokeWidth="3"
                        strokeDasharray={`${analysis.atsScore}, 100`}
                        strokeLinecap="round"
                        className="transition-all duration-1000 ease-in-out"
                        />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center text-2xl font-bold text-foreground">
                        {analysis.atsScore}
                    </div>
                </div>
                <div>
                    <CardTitle className="text-2xl">Your ATS Score</CardTitle>
                    <p className="text-muted-foreground">
                        {analysis.atsScore >= 80 ? 'Excellent job! Your resume is well-optimized.' :
                        analysis.atsScore >= 60 ? 'Good start, but there is room for improvement.' :
                        'Your resume needs significant improvements to pass ATS filters.'}
                    </p>
                </div>
            </CardHeader>
          </Card>
          
          <Alert>
            <Terminal className="h-4 w-4" />
            <AlertTitle>Reasoning</AlertTitle>
            <AlertDescription>{analysis.reasoning}</AlertDescription>
          </Alert>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ListChecks className="text-accent" />
                Improvement Suggestions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {analysis.suggestions.map((suggestion, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                    <span>{suggestion}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
