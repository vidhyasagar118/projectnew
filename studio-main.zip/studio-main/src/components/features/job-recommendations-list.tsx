import { mockJobs, type Job } from '@/lib/mock-jobs';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin } from 'lucide-react';

function JobCard({ job }: { job: Job }) {
  const logo = PlaceHolderImages.find(img => img.id === job.logoId);
  return (
    <Card className="flex flex-col hover:shadow-xl transition-shadow duration-300">
      <CardHeader className="flex flex-row items-start gap-4">
        {logo && (
          <Image
            src={logo.imageUrl}
            alt={`${job.company} logo`}
            data-ai-hint={logo.imageHint}
            width={56}
            height={56}
            className="rounded-lg border aspect-square object-cover"
          />
        )}
        <div className="flex-1">
          <CardTitle>{job.title}</CardTitle>
          <CardDescription className="font-medium">{job.company}</CardDescription>
          <div className="flex items-center text-sm text-muted-foreground mt-1">
            <MapPin className="mr-1 h-4 w-4" />
            {job.location}
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1">
        <p className="text-sm text-muted-foreground line-clamp-3">{job.description}</p>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <Badge variant={job.type === 'Internship' ? 'secondary' : 'outline'}>{job.type}</Badge>
        <Button>Apply Now</Button>
      </CardFooter>
    </Card>
  );
}

export function JobRecommendationsList() {
  const jobs = mockJobs;

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {jobs.map(job => (
        <JobCard key={job.id} job={job} />
      ))}
    </div>
  );
}
