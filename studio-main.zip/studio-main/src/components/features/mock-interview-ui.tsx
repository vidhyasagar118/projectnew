'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { handleInterviewFeedback } from '@/app/actions';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Sparkles, Wand2 } from 'lucide-react';
import type { MockInterviewFeedbackOutput } from '@/ai/flows/mock-interview-feedback';
import { useToast } from '@/hooks/use-toast';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';

const formSchema = z.object({
  jobDescription: z.string().min(50, 'Please provide a more detailed job description.'),
  interviewResponse: z.string().min(20, 'Please provide a more detailed answer.'),
});

export function MockInterviewUI() {
  const [feedback, setFeedback] = useState<MockInterviewFeedbackOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      jobDescription: '',
      interviewResponse: '',
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsLoading(true);
    setFeedback(null);
    
    // Using a static user name for now. This would come from auth in a real app.
    const result = await handleInterviewFeedback({ ...values, userName: "Alex" });

    if (result.error) {
      toast({
        variant: 'destructive',
        title: 'Feedback Generation Failed',
        description: result.error,
      });
    } else if (result.data) {
      setFeedback(result.data);
    }
    setIsLoading(false);
  };

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="jobDescription"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Job Description</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Paste the job description here..."
                    className="min-h-[150px]"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="interviewResponse"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Your Answer</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Tell me about a time you faced a challenge at work..."
                    className="min-h-[150px]"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" disabled={isLoading} className="w-full sm:w-auto">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Feedback...
              </>
            ) : (
              <>
                <Wand2 className="mr-2 h-4 w-4" />
                Get Feedback
              </>
            )}
          </Button>
        </form>
      </Form>

      {isLoading && (
         <div className="flex flex-col items-center justify-center space-y-4 rounded-lg border border-dashed p-8">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <p className="text-muted-foreground">Our AI coach is analyzing your response...</p>
        </div>
      )}

      {feedback && (
        <div className="space-y-6 animate-in fade-in-50 duration-500">
            <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
                <Sparkles className="text-accent"/>
                Your Feedback
            </h2>
            <Card>
                <CardHeader>
                    <CardTitle>Overall Feedback</CardTitle>
                </CardHeader>
                <CardContent>
                    <p>{feedback.overallFeedback}</p>
                </CardContent>
            </Card>
             <div className="grid md:grid-cols-3 gap-4">
                <Card>
                    <CardHeader>
                        <CardTitle>Vocal Tone</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p>{feedback.vocalToneFeedback}</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Confidence Level</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p>{feedback.confidenceLevelFeedback}</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Answer Quality</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p>{feedback.answerQualityFeedback}</p>
                    </CardContent>
                </Card>
            </div>
        </div>
      )}
    </div>
  );
}
