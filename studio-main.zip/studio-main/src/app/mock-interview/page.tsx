import { MockInterviewUI } from "@/components/features/mock-interview-ui";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Mic } from 'lucide-react';

export default function MockInterviewPage() {
  return (
    <div className="container mx-auto py-10">
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Mock Interview Coach</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Practice your interview skills and get instant, AI-powered feedback.
          </p>
        </div>
        <Card className="max-w-4xl mx-auto shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mic />
              Your Interview Session
            </CardTitle>
            <CardDescription>
              Paste the job description and your answer to a common interview question to receive feedback.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <MockInterviewUI />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
