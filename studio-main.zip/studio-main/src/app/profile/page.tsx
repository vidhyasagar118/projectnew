import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function ProfilePage() {
  return (
    <div className="container mx-auto py-10">
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Your Profile</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Manage your personal information, resumes, and job preferences.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3 max-w-5xl mx-auto">
          <div className="md:col-span-1">
            <Card>
              <CardHeader className="items-center text-center">
                <Avatar className="h-24 w-24 mb-2">
                  <AvatarImage src="https://picsum.photos/seed/user-avatar/100/100" alt="User avatar" data-ai-hint="person portrait" />
                  <AvatarFallback>AD</AvatarFallback>
                </Avatar>
                <CardTitle>Alex Doe</CardTitle>
                <CardDescription>alex.doe@example.com</CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" variant="outline" disabled>Edit Profile</Button>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
                <CardDescription>This information is private and will not be shared.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" defaultValue="Alex Doe" disabled />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" defaultValue="alex.doe@example.com" disabled />
                </div>
                <Separator />
                <h3 className="text-lg font-medium">Stored Resumes</h3>
                <div className="border rounded-lg p-4 flex items-center justify-between">
                    <div>
                        <p className="font-medium">Software_Engineer_Resume.pdf</p>
                        <p className="text-sm text-muted-foreground">Uploaded on July 15, 2024</p>
                    </div>
                    <Button variant="ghost" size="sm" disabled>Delete</Button>
                </div>
                <Button variant="outline" className="w-full" disabled>Upload New Resume</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
