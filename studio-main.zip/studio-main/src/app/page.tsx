import { ResumeAtsChecker } from "@/components/features/resume-ats-checker";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="container mx-auto py-10">
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Resume ATS Checker</h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Get an instant analysis of your resume and see how it scores against Applicant Tracking Systems.
          </p>
        </div>
        <Card className="max-w-4xl mx-auto shadow-lg">
          <CardHeader>
            <CardTitle>Upload Your Resume</CardTitle>
            <CardDescription>Upload your resume in PDF format to get started.</CardDescription>
          </CardHeader>
          <CardContent>
            <ResumeAtsChecker />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
