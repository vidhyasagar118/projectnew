'use server';

import {
  analyzeResumeAts,
  AnalyzeResumeAtsInput,
  AnalyzeResumeAtsOutput,
} from '@/ai/flows/resume-ats-analysis';
import {
  mockInterviewFeedback,
  MockInterviewFeedbackInput,
  MockInterviewFeedbackOutput,
} from '@/ai/flows/mock-interview-feedback';
import { z } from 'zod';
import { action } from '@/lib/action';

export const handleResumeAnalysis = action(
    z.object({
        resumeDataUri: z.string().startsWith('data:application/pdf;base64,', {message: 'File must be a PDF data URI.'}),
    }),
    async (input): Promise<AnalyzeResumeAtsOutput> => {
        return analyzeResumeAts(input as AnalyzeResumeAtsInput);
    }
);

export const handleInterviewFeedback = action(
    z.object({
        interviewResponse: z.string(),
        jobDescription: z.string(),
        userName: z.string(),
    }),
    async (input): Promise<MockInterviewFeedbackOutput> => {
        return mockInterviewFeedback(input as MockInterviewFeedbackInput);
    }
);
