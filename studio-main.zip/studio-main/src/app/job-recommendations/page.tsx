import { JobRecommendationsList } from "@/components/features/job-recommendations-list";

export default function JobRecommendationsPage() {
  return (
    <div className="container mx-auto py-10">
        <div className="space-y-8">
            <div className="text-center">
                <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Personalized Job Recommendations</h1>
                <p className="mt-2 text-lg text-muted-foreground">
                    Discover job and internship opportunities tailored to your profile.
                </p>
            </div>
            <JobRecommendationsList />
        </div>
    </div>
  );
}
