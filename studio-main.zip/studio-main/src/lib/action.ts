import { z } from 'zod';

export const action =
  <TInput extends z.ZodTypeAny, TOutput>(
    schema: TInput,
    handler: (input: z.infer<TInput>) => Promise<TOutput>
  ) =>
  async (data: z.infer<TInput>): Promise<{ data: TOutput | null; error: string | null }> => {
    try {
      const parsedData = schema.parse(data);
      const result = await handler(parsedData);
      return { data: result, error: null };
    } catch (e) {
      if (e instanceof z.ZodError) {
        return { data: null, error: e.errors.map((err) => err.message).join(', ') };
      }
      if (e instanceof Error) {
        return { data: null, error: e.message };
      }
      return { data: null, error: 'An unknown error occurred.' };
    }
  };
