export type Job = {
    id: string;
    title: string;
    company: string;
    location: string;
    type: 'Full-time' | 'Internship' | 'Contract';
    description: string;
    logoId: string; // Corresponds to an ID in placeholder-images.json
};
  
export const mockJobs: Job[] = [
    {
        id: '1',
        title: 'Software Engineer, Frontend',
        company: 'Innovate Inc.',
        location: 'San Francisco, CA',
        type: 'Full-time',
        description: 'Join our team to build next-generation web applications. Strong experience with React and TypeScript is required.',
        logoId: 'company-innovate',
    },
    {
        id: '2',
        title: 'Product Management Intern',
        company: 'FutureTech',
        location: 'New York, NY (Remote)',
        type: 'Internship',
        description: 'A 12-week internship program for aspiring product managers. You will work on a real product and see it through launch.',
        logoId: 'company-futuretech',
    },
    {
        id: '3',
        title: 'Data Scientist',
        company: 'DataDriven Co.',
        location: 'Austin, TX',
        type: 'Full-time',
        description: 'We are looking for a data scientist to help us make sense of our vast datasets. Experience with Python, SQL, and machine learning frameworks is essential.',
        logoId: 'company-datadriven',
    },
    {
        id: '4',
        title: 'UX/UI Designer',
        company: 'Creative Solutions',
        location: 'Seattle, WA',
        type: 'Contract',
        description: 'A 6-month contract to redesign our mobile application. A strong portfolio of mobile design work is required.',
        logoId: 'company-creative',
    },
    {
        id: '5',
        title: 'Backend Engineer (Go)',
        company: 'ScaleFast',
        location: 'Remote',
        type: 'Full-time',
        description: 'Help build and maintain our high-performance microservices architecture using Go. Experience with distributed systems is a plus.',
        logoId: 'company-scalefast',
    },
];
