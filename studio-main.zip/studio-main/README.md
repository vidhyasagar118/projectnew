# Career Ascent

An AI-powered resume and interview coach to help you land your dream job. This application provides resume analysis, mock interviews with AI feedback, and personalized job recommendations.