# **App Name**: Career Ascent

## Core Features:

- Resume ATS Checker: Analyze uploaded resumes and provide an ATS score with suggestions for improvement based on keyword analysis, formatting, and content optimization; the analysis LLM uses an attached tool.
- Mock Interview Simulation: Conduct AI-driven mock interviews with real-time feedback on vocal tone, confidence levels, and answer quality. Uses NLP to analyze responses.
- Personalized Job Recommendations: Fetch and display relevant job and internship recommendations from external APIs (LinkedIn, Indeed) based on user profile and resume content.
- User Profile Management: Securely store user resumes, job preferences, and performance history for personalized recommendations and interview practice.

## Style Guidelines:

- Primary color: Deep sky blue (#00BFFF) for a sense of trust and competence.
- Background color: Light gray (#EEEEEE), providing a clean and neutral backdrop.
- Accent color: Teal (#008080) to highlight important CTAs and information.
- Body and headline font: 'Inter', a grotesque-style sans-serif with a modern, machined, objective, neutral look; suitable for headlines or body text
- Crisp, professional icons representing job-related concepts.
- Clean, structured layouts for easy resume uploading, clear presentation of feedback, and straightforward access to job recommendations.
- Subtle transitions and loading animations for a smooth user experience.